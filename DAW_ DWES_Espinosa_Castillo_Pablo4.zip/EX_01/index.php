<!DOCTYPE html>
<html>
<head>
    <title>Formulario</title>
</head>
<body>
    <form method="POST" action="">
        <label for="texto">Introduce una palabra:</label>
        <input type="text" name="texto" id="texto">
        <input type="submit" value="Enviar">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $texto = $_POST["texto"];
        $longitud = strlen($texto);
        echo "La longitud de la palabra introducida es: " . $longitud;
    }
    ?>
</body>
</html>

