Este ejercicio se resuelve con el metodo POST,
el usuario debe introducir una cadena de texto y se
mostrará la longitud de este.