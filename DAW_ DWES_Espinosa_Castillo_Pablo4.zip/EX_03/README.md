Este ejercicio también es similar al primero, pero en
este caso se imprime por pantalla las frases x veces
según el número que introduzcas en el formulario.