<!DOCTYPE html>
<html>
<head>
    <title>Formulario</title>
</head>
<body>
<form method="POST" action="">
    <label for="numero">Introduce un número:</label>
    <input type="number" name="numero" id="numero">
    <input type="submit" value="Enviar">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numero = $_POST["numero"];
    echo "Escribiendo " . $numero . " líneas:<br>";
    for ($i = 1; $i <= $numero; $i++) {
        echo "Línea " . $i . "<br>";
    }
}
?>
</body>
</html>
