<!DOCTYPE html>
<html>
<head>
    <title>Formulario</title>
</head>
<body>
<form method="POST" action="">
    <label for="calculo">Introduce un cálculo matemático:</label>
    <input type="text" name="calculo" id="calculo">
    <input type="submit" value="Enviar">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $calculo = $_POST["calculo"];
    $resultado = eval('return '.$calculo.';');
    echo "Operación: " . $calculo . "<br>";
    echo "Resultado: " . $resultado;
}
?>
</body>
</html>
