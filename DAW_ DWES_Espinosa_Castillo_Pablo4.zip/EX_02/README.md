Este ejercicio es muy similar al anterior pero en este
caso el usuario tiene que introducir un calculo a mano
y este se retorna ya resuelto.