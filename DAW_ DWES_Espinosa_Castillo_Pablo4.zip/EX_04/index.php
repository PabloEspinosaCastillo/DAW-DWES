<!DOCTYPE html>
<html>
<head>
    <title>Formulario</title>
</head>
<body>
<form method="POST" action="">
    <label for="nombre">Nombre:</label>
    <input type="text" name="nombre" id="nombre"><br>

    <label for="apellidos">Apellidos:</label>
    <input type="text" name="apellidos" id="apellidos"><br>

    <label for="contrasena">Contraseña:</label>
    <input type="password" name="contrasena" id="contrasena"><br>

    <label for="tipo">Alumno o Profesor:</label>
    <input type="checkbox" name="tipo" value="Alumno"> Alumno
    <input type="checkbox" name="tipo" value="Profesor"> Profesor<br>

    <label for="foto">Foto:</label>
    <input type="text" name="foto" id="foto"><br>

    <label for="edad">Edad:</label>
    <input type="number" name="edad" id="edad"><br>

    <label for="comentarios">Comentarios:</label>
    <textarea name="comentarios" id="comentarios"></textarea><br>

    <input type="hidden" name="test" value="myPrueba">

    <input type="submit" value="Enviar">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST["nombre"];
    $apellidos = $_POST["apellidos"];
    $contrasena = $_POST["contrasena"];
    $tipo = $_POST["tipo"];
    $foto = $_POST["foto"];
    $edad = $_POST["edad"];
    $comentarios = $_POST["comentarios"];
    $test = $_POST["test"];

    echo "Nombre: " . $nombre . "<br>";
    echo "Apellidos: " . $apellidos . "<br>";
    echo "Contraseña: " . $contrasena . "<br>";
    echo "Tipo: " . $tipo . "<br>";
    echo "Foto: " . $foto . "<br>";
    echo "Edad: " . $edad . "<br>";
    echo "Comentarios: " . $comentarios . "<br>";
    echo "Test: " . $test . "<br>";
}
?>
</body>
</html>
