Este ejerciico es un formulario que te pide que 
introduzcas varios parámetros por pantalla, entre ellos
hay uno oculto que sale al enviar el formulario. 